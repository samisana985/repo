package com.example.demntia;

import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;

@Service
public class TransactionAnalysisService {

    @Autowired
    private ChatLanguageModel chatLanguageModel;

    public String analyzeTransactions() throws IOException {
        String transactionHistory = readTransactionHistory();
        String prompt = "Analyze the following transaction history for a dementia patient. " +
                "Identify any potentially repeated transactions that might indicate the patient " +
                "forgot about previous transactions. Provide a summary of your findings:\n\n" +
                transactionHistory;

        return chatLanguageModel.generate(prompt);
    }

    private String readTransactionHistory() throws IOException {
        ClassPathResource resource = new ClassPathResource("transaction_history.txt");
        return new String(Files.readAllBytes(resource.getFile().toPath()));
    }
}
