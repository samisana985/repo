package com.example.demntia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemntiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemntiaApplication.class, args);
	}

}
